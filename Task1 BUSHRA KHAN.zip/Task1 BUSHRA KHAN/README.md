# Customer Behavior Analytics & Churn Prediction Dashboard

**Task ID:** ML-INT-1  
**Domain:** Machine Learning  
**Intern:** Shoaib Ahmed

This project analyzes telecom customer behavior and predicts churn probability using Logistic Regression and Random Forest models. It also includes customer segmentation, business insights, visualizations, a prediction output file, and a Streamlit dashboard.

## How to Run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the complete pipeline:
```bash
python src/train_model.py
```

3. Run the Streamlit dashboard:
```bash
streamlit run src/app.py
```

4. Open the notebook:
```bash
jupyter notebook notebooks/churn_prediction_analysis.ipynb
```

## Folder Structure
```text
Task-ML-INT-1_ShoaibAhmed/
├── data/
├── notebooks/
├── src/
├── models/
├── visualizations/
├── reports/
├── demo/
├── README.md
└── requirements.txt
```

## Main Outputs
- Churn distribution chart
- Revenue trend chart
- Customer segment chart
- Correlation heatmap
- Contract/payment category comparisons
- Model evaluation report
- Customer-level churn predictions
- Working demo video

## Submission Notes
Do not include `node_modules` or `.git` folders. Submit this folder as a ZIP file through the official Google Form only.
