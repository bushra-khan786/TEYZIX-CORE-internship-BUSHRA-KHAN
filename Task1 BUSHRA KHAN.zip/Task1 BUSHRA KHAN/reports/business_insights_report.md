# Customer Behavior Analytics & Churn Prediction Report

## Project Overview
This project completes the TEYZIX Core internship task **ML-INT-1: Customer Behavior Analytics & Churn Prediction Dashboard**. It loads the customer dataset, cleans it, engineers behavior-based features, creates visualizations, trains two machine learning models, segments customers, predicts churn probability, and summarizes business insights.

## Dataset Summary
- Total customers: 7043
- Total columns after feature engineering: 45
- Overall churn rate: 26.54%
- Missing values after cleaning: 0
- Duplicate customer IDs after cleaning: 0
- Total historical revenue: $16,038,378.93
- Current monthly revenue: $456,032.06
- Estimated annual revenue at risk from churned customers: $1,669,429.49

## Feature Engineering Performed
- Usage frequency proxy from number of active services divided by tenure.
- Tenure groups for customer lifecycle analysis.
- Payment risk patterns from payment method and paperless billing.
- Support interaction proxy from TechSupport availability because the dataset does not include ticket counts.
- Service count, streaming count, no-security-or-support flag, contract risk score, payment risk score, and revenue trend proxy.
- Customer value score and segmentation into High value, Medium value, and Low value customers.

## Model Results
| model               |   accuracy |   precision |   recall |   f1_score |   roc_auc | confusion_matrix        |
|:--------------------|-----------:|------------:|---------:|-----------:|----------:|:------------------------|
| Logistic Regression |     0.741  |      0.5077 |   0.7941 |     0.6194 |    0.8462 | [[747, 288], [77, 297]] |
| Random Forest       |     0.7715 |      0.5522 |   0.7353 |     0.6307 |    0.8428 | [[812, 223], [99, 275]] |

Best model selected: **Logistic Regression** based on ROC-AUC and F1-score balance.

## Top Churn Patterns
- Contract type is a major churn signal. Highest churn appears in **Month-to-month** customers with a churn rate of 42.71%.
- Payment method is also important. Highest churn appears in **Electronic check** users with a churn rate of 45.29%.
- Segment with highest churn: **Medium value** at 36.97%.
- Customers without online security and tech support show higher churn risk than customers with protective/support services.
- Short-tenure customers with month-to-month contracts and electronic check payments are the highest-risk group.

## Important Model Drivers


## Business Recommendations
1. Prioritize retention offers for high-probability churn customers, especially month-to-month and electronic check users.
2. Encourage longer contracts using discounts or loyalty benefits.
3. Promote OnlineSecurity and TechSupport bundles because customers without these services show higher churn risk.
4. Monitor high monthly charge customers with low tenure because they represent both churn risk and revenue risk.
5. Use the prediction file to contact High-risk customers before renewal or billing cycles.

## Files Produced
- `notebooks/churn_prediction_analysis.ipynb`: complete notebook.
- `src/`: modular Python scripts and Streamlit dashboard.
- `visualizations/`: charts required by the task.
- `models/churn_model.pkl`: trained best model.
- `reports/customer_churn_predictions.csv`: churn probability and risk category for each customer.
- `demo/working_demo_video.mp4`: demo video included for submission.
