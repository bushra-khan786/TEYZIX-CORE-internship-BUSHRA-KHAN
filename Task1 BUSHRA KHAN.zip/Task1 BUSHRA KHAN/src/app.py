from pathlib import Path
import pandas as pd
import streamlit as st
import joblib
from utils import load_and_clean_data, add_behavior_features

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="Customer Churn Dashboard", layout="wide")
st.title("Customer Behavior Analytics & Churn Prediction Dashboard")

raw = load_and_clean_data(ROOT / "data" / "customer_churn.csv")
df = add_behavior_features(raw)
model = joblib.load(ROOT / "models" / "churn_model.pkl")

st.subheader("Key Metrics")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Customers", f"{len(df):,}")
col2.metric("Churn Rate", f"{df['ChurnFlag'].mean()*100:.2f}%")
col3.metric("Monthly Revenue", f"${df['MonthlyCharges'].sum():,.0f}")
col4.metric("Annual Revenue at Risk", f"${(df.loc[df.ChurnFlag.eq(1),'MonthlyCharges']*12).sum():,.0f}")

st.subheader("Visual Insights")
left, right = st.columns(2)
with left:
    st.image(str(ROOT / "visualizations" / "churn_distribution.png"), caption="Churn Distribution")
    st.image(str(ROOT / "visualizations" / "customer_segments.png"), caption="Customer Segments")
with right:
    st.image(str(ROOT / "visualizations" / "revenue_trend_by_tenure.png"), caption="Revenue Trend")
    st.image(str(ROOT / "visualizations" / "churn_by_contract.png"), caption="Churn by Contract")

st.subheader("Predict One Customer")
with st.form("prediction_form"):
    gender = st.selectbox("Gender", sorted(df["gender"].unique()))
    senior = st.selectbox("Senior Citizen", [0, 1])
    partner = st.selectbox("Partner", sorted(df["Partner"].unique()))
    dependents = st.selectbox("Dependents", sorted(df["Dependents"].unique()))
    tenure = st.slider("Tenure", 0, 72, 12)
    internet = st.selectbox("Internet Service", sorted(df["InternetService"].unique()))
    contract = st.selectbox("Contract", sorted(df["Contract"].unique()))
    payment = st.selectbox("Payment Method", sorted(df["PaymentMethod"].unique()))
    monthly = st.slider("Monthly Charges", 0.0, 130.0, 70.0)
    total = st.number_input("Total Charges", min_value=0.0, value=float(monthly * max(tenure, 1)))
    submitted = st.form_submit_button("Predict Churn Risk")

if submitted:
    sample = pd.DataFrame([{
        "customerID": "CUSTOM", "gender": gender, "SeniorCitizen": senior, "Partner": partner, "Dependents": dependents,
        "tenure": tenure, "PhoneService": "Yes", "MultipleLines": "No", "InternetService": internet,
        "OnlineSecurity": "No", "OnlineBackup": "No", "DeviceProtection": "No", "TechSupport": "No",
        "StreamingTV": "No", "StreamingMovies": "No", "Contract": contract, "PaperlessBilling": "Yes",
        "PaymentMethod": payment, "MonthlyCharges": monthly, "TotalCharges": total, "Churn": "No"
    }])
    sample_fe = add_behavior_features(sample)
    X_sample = sample_fe.drop(columns=["customerID", "Churn", "ChurnFlag", "estimated_revenue_at_risk"])
    proba = model.predict_proba(X_sample)[0, 1]
    risk = "Low risk" if proba < 0.35 else "Medium risk" if proba < 0.65 else "High risk"
    st.success(f"Churn probability: {proba:.2%} | Risk category: {risk}")

st.subheader("Customer-level Predictions")
pred = pd.read_csv(ROOT / "reports" / "customer_churn_predictions.csv")
st.dataframe(pred.head(50), use_container_width=True)
