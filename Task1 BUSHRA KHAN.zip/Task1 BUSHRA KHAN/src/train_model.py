from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from utils import load_and_clean_data, add_behavior_features

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "customer_churn.csv"

df = add_behavior_features(load_and_clean_data(DATA_PATH))
df.to_csv(ROOT / "data" / "processed_customer_churn.csv", index=False)

y = df["ChurnFlag"]
X = df.drop(columns=["customerID", "Churn", "ChurnFlag", "estimated_revenue_at_risk"])
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()
num_cols = X.select_dtypes(include=["number", "bool"]).columns.tolist()

preprocess = ColumnTransformer([
    ("num", StandardScaler(), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
models = {
    "Logistic Regression": LogisticRegression(max_iter=1200, class_weight="balanced", random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=350, max_depth=12, min_samples_leaf=6, class_weight="balanced_subsample", random_state=42, n_jobs=-1),
}

results = []
fitted = {}
for name, clf in models.items():
    pipe = Pipeline([("preprocess", preprocess), ("model", clf)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    proba = pipe.predict_proba(X_test)[:, 1]
    results.append({
        "model": name,
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred),
        "recall": recall_score(y_test, pred),
        "f1_score": f1_score(y_test, pred),
        "roc_auc": roc_auc_score(y_test, proba),
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
    })
    fitted[name] = pipe

res = pd.DataFrame(results)
res.to_csv(ROOT / "reports" / "model_results.csv", index=False)
best_name = res.sort_values(["roc_auc", "f1_score"], ascending=False).iloc[0]["model"]
best_pipe = fitted[best_name]
joblib.dump(best_pipe, ROOT / "models" / "churn_model.pkl")

prob = best_pipe.predict_proba(X)[:, 1]
pred_df = df[["customerID", "gender", "tenure", "Contract", "PaymentMethod", "MonthlyCharges", "TotalCharges", "customer_segment", "Churn"]].copy()
pred_df["churn_probability"] = prob.round(4)
pred_df["risk_category"] = pd.cut(pred_df["churn_probability"], bins=[-0.01, 0.35, 0.65, 1.0], labels=["Low risk", "Medium risk", "High risk"])
pred_df.sort_values("churn_probability", ascending=False).to_csv(ROOT / "reports" / "customer_churn_predictions.csv", index=False)

with open(ROOT / "models" / "model_metadata.json", "w") as f:
    json.dump({"best_model": best_name, "features": X.columns.tolist(), "categorical_columns": cat_cols, "numeric_columns": num_cols}, f, indent=2)

print(res)
print(f"Best model saved: {best_name}")
