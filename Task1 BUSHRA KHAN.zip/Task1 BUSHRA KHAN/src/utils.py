import numpy as np
import pandas as pd

def load_and_clean_data(path):
    df = pd.read_csv(path)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
    df = df.drop_duplicates(subset=["customerID"]).copy()
    for col in ["tenure", "MonthlyCharges", "TotalCharges"]:
        low, high = df[col].quantile([0.01, 0.99])
        df[col] = df[col].clip(low, high)
    return df

def add_behavior_features(df):
    df = df.copy()
    df["ChurnFlag"] = (df["Churn"].str.lower() == "yes").astype(int)
    service_cols = ["PhoneService", "MultipleLines", "OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies"]
    for col in service_cols:
        df[col + "_flag"] = (df[col].astype(str).str.lower() == "yes").astype(int)
    df["service_count"] = df[[c + "_flag" for c in service_cols]].sum(axis=1)
    df["usage_frequency_proxy"] = df["service_count"] / np.maximum(df["tenure"], 1)
    df["tenure_group"] = pd.cut(df["tenure"], bins=[-1, 12, 24, 48, 72], labels=["0-12 months", "13-24 months", "25-48 months", "49-72 months"])
    df["avg_charge_per_tenure"] = df["TotalCharges"] / np.maximum(df["tenure"], 1)
    df["avg_monthly_total_ratio"] = df["TotalCharges"] / np.maximum(df["MonthlyCharges"], 1)
    df["payment_risk_pattern"] = np.select([df["PaymentMethod"].eq("Electronic check"), df["PaperlessBilling"].eq("Yes")], ["Electronic check", "Paperless billing"], default="Other")
    df["support_interaction_count_proxy"] = np.where(df["TechSupport"].eq("Yes"), 1, 0)
    df["no_security_or_support"] = ((df["OnlineSecurity"].eq("No")) & (df["TechSupport"].eq("No"))).astype(int)
    df["streaming_count"] = df[["StreamingTV_flag", "StreamingMovies_flag"]].sum(axis=1)
    df["contract_risk_score"] = df["Contract"].map({"Month-to-month": 3, "One year": 2, "Two year": 1}).astype(int)
    df["payment_risk_score"] = df["PaymentMethod"].map({"Electronic check": 3, "Mailed check": 2, "Bank transfer (automatic)": 1, "Credit card (automatic)": 1}).astype(int)
    df["revenue_trend_proxy"] = df["MonthlyCharges"] - df["avg_charge_per_tenure"]
    df["estimated_revenue_at_risk"] = df["MonthlyCharges"] * 12 * df["ChurnFlag"]
    value_score = 0.55 * pd.qcut(df["TotalCharges"].rank(method="first"), 3, labels=[1,2,3]).astype(int) + 0.30 * pd.qcut(df["MonthlyCharges"].rank(method="first"), 3, labels=[1,2,3]).astype(int) + 0.15 * pd.qcut(df["service_count"].rank(method="first"), 3, labels=[1,2,3]).astype(int)
    df["customer_value_score"] = value_score
    df["customer_segment"] = pd.cut(value_score, bins=[0,1.75,2.45,3.01], labels=["Low value", "Medium value", "High value"], include_lowest=True)
    return df
