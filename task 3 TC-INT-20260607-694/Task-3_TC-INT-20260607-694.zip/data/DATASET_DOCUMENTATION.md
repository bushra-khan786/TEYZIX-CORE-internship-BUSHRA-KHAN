# Dataset Documentation

## Dataset Name
`household_electricity_dataset.csv`

## Overview
An **original, synthetically generated** household electricity-usage dataset created
specifically for this project. **No public dataset (Kaggle, UCI, GitHub, or any other
source) was used at any stage.**

- **Total Records:** 656 (raw) → 650 (after cleaning)
- **Total Features:** 16 input features + 1 target variable
- **Target Variable:** `Daily_Electricity_Consumption_kWh`

## Collection / Generation Method
The dataset was produced using a **physics-informed synthetic data generation approach**
(see `src/generate_dataset.py`). Rather than assigning random numbers, each household's
daily electricity consumption is computed from a realistic additive model:

```
Consumption = Base Load
            + AC_Hours   x Typical AC Power Rating (1.5 kW)
            + Fan_Hours  x Typical Fan Power Rating (0.075 kW)
            + Fridge_Hours x Typical Fridge Power Rating (0.15 kW)
            + Washing_Machine_Hours x 0.5 kW
            + Water_Motor_Hours x 0.75 kW
            + Lighting_Hours x 0.08 kW
            + Heater_Hours x 1.2 kW
            + TV/Electronics_Hours x 0.12 kW
            + Household-size and room-count effects
            x House-Type multiplier (Apartment / Independent House / Villa)
            x Random household-efficiency factor
            + Gaussian noise (realistic measurement variance)
```

Appliance usage hours themselves are sampled conditionally — for example, AC usage
hours increase with outdoor temperature and are suppressed in winter; heater usage
increases in winter and cold temperatures; washing-machine usage is slightly higher
on weekends. This produces realistic feature interactions and non-trivial relationships
for the models to learn, rather than a purely linear toy dataset.

To simulate real-world data-quality issues (which the preprocessing pipeline then
handles), the raw dataset intentionally includes:
- ~2% missing values in `AC_Usage_Hours`, `Lighting_Hours`, and `Outdoor_Temperature_C`
- ~1% duplicate rows
- A small number (~0.5%) of extreme outlier records

## Feature Description

| Feature | Type | Description |
|---|---|---|
| House_Type | Categorical | Apartment / Independent House / Villa |
| Family_Members | Numeric | Number of people living in the household (1-8) |
| Num_Rooms | Numeric | Number of rooms in the house (1-8) |
| AC_Usage_Hours | Numeric | Daily air-conditioner usage (hours) |
| Fan_Usage_Hours | Numeric | Daily fan usage (hours) |
| Fridge_Usage_Hours | Numeric | Daily refrigerator active-usage hours |
| Washing_Machine_Hours | Numeric | Daily washing machine usage (hours) |
| Water_Motor_Hours | Numeric | Daily water motor/pump usage (hours) |
| Lighting_Hours | Numeric | Daily lighting usage (hours) |
| Heater_Usage_Hours | Numeric | Daily heater usage (hours, mainly winter) |
| TV_Electronics_Hours | Numeric | Daily TV/other electronics usage (hours) |
| Daily_Appliance_Count | Numeric | Total distinct appliances used that day |
| Outdoor_Temperature_C | Numeric | Outdoor temperature (Celsius) |
| Day_of_Week | Categorical | Monday–Sunday |
| Season | Categorical | Summer / Winter / Spring / Autumn |
| Is_Working_Day | Binary | 1 = working day, 0 = weekend/holiday |
| **Daily_Electricity_Consumption_kWh** | **Numeric (Target)** | **Total daily electricity consumption in kWh** |

## Reproducibility
The generator uses a fixed random seed (`RANDOM_SEED = 42`), so running
`python3 src/generate_dataset.py` will always reproduce the identical dataset.
