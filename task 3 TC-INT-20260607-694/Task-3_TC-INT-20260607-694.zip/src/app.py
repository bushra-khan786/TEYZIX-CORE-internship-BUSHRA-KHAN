"""
app.py
-------
Streamlit web application: Smart Electricity Consumption Prediction &
Energy Optimization System.

Run with:  streamlit run app.py
"""

import streamlit as st
import pandas as pd
import joblib
import sys
import os

sys.path.append(os.path.dirname(__file__))
from feature_engineering import engineer_features
from recommendations import generate_recommendations

MODELS_DIR = os.path.join(os.path.dirname(__file__), "..", "models")

st.set_page_config(page_title="Smart Electricity Predictor", page_icon="⚡", layout="centered")


@st.cache_resource
def load_artifacts():
    model = joblib.load(os.path.join(MODELS_DIR, "best_model.pkl"))
    features = joblib.load(os.path.join(MODELS_DIR, "feature_list.pkl"))
    encoders = joblib.load(os.path.join(MODELS_DIR, "label_encoders.pkl"))
    return model, features, encoders


model, features, encoders = load_artifacts()

st.title("⚡ Smart Electricity Consumption Prediction")
st.caption("TEYZIX CORE Internship — Task ML-3 | Energy Optimization System")

with st.form("prediction_form"):
    st.subheader("Household Details")
    col1, col2 = st.columns(2)
    with col1:
        house_type = st.selectbox("House Type", encoders["House_Type"].classes_)
        family_members = st.slider("Family Members", 1, 8, 4)
        num_rooms = st.slider("Number of Rooms", 1, 8, 3)
        season = st.selectbox("Season", encoders["Season"].classes_)
        day = st.selectbox("Day of Week", encoders["Day_of_Week"].classes_)
        is_working_day = st.selectbox("Is Working Day?", ["Yes", "No"])
    with col2:
        temp = st.slider("Outdoor Temperature (°C)", 5, 48, 32)
        appliance_count = st.slider("Total Daily Appliance Count", 3, 20, 8)

    st.subheader("Appliance Usage (hours/day)")
    col3, col4 = st.columns(2)
    with col3:
        ac_hours = st.slider("AC Usage Hours", 0.0, 18.0, 4.0, 0.5)
        fan_hours = st.slider("Fan Usage Hours", 0.0, 24.0, 10.0, 0.5)
        fridge_hours = st.slider("Fridge Usage Hours", 0.0, 24.0, 22.0, 0.5)
        heater_hours = st.slider("Heater Usage Hours", 0.0, 12.0, 0.0, 0.5)
    with col4:
        wm_hours = st.slider("Washing Machine Hours", 0.0, 3.0, 0.5, 0.1)
        motor_hours = st.slider("Water Motor Hours", 0.0, 4.0, 1.0, 0.1)
        lighting_hours = st.slider("Lighting Hours", 0.0, 14.0, 6.0, 0.5)
        tv_hours = st.slider("TV/Electronics Hours", 0.0, 14.0, 4.0, 0.5)

    submitted = st.form_submit_button("🔮 Predict Consumption")

if submitted:
    row = {
        "Family_Members": family_members, "Num_Rooms": num_rooms,
        "AC_Usage_Hours": ac_hours, "Fan_Usage_Hours": fan_hours,
        "Fridge_Usage_Hours": fridge_hours, "Washing_Machine_Hours": wm_hours,
        "Water_Motor_Hours": motor_hours, "Lighting_Hours": lighting_hours,
        "Heater_Usage_Hours": heater_hours, "TV_Electronics_Hours": tv_hours,
        "Daily_Appliance_Count": appliance_count, "Outdoor_Temperature_C": temp,
        "House_Type_Encoded": encoders["House_Type"].transform([house_type])[0],
        "Day_of_Week_Encoded": encoders["Day_of_Week"].transform([day])[0],
        "Season_Encoded": encoders["Season"].transform([season])[0],
        "Is_Working_Day": 1 if is_working_day == "Yes" else 0,
    }

    df_row = pd.DataFrame([row])
    df_row, _ = engineer_features(df_row)
    prediction = model.predict(df_row[features])[0]
    result = generate_recommendations(row, prediction)

    st.divider()
    st.subheader("📊 Prediction Results")

    m1, m2, m3 = st.columns(3)
    m1.metric("Daily Consumption", f"{prediction:.2f} kWh")
    m2.metric("Monthly Consumption", f"{result['estimated_monthly_kwh']} kWh")
    m3.metric("Efficiency Score", f"{result['efficiency_score']}/100")

    m4, m5 = st.columns(2)
    m4.metric("Estimated Monthly Bill", f"PKR {result['estimated_monthly_bill_pkr']:,}")
    m5.metric("Potential Monthly Savings",
               f"PKR {result['estimated_monthly_savings_pkr']:,} ({result['estimated_savings_percent']}%)")

    st.markdown("**⏰ Peak Usage Hours**")
    for p in result["peak_hours"]:
        st.write(f"- {p}")

    st.markdown("**💡 Personalized Energy-Saving Recommendations**")
    for r in result["recommendations"]:
        st.info(r)

    st.caption("Note: Electricity rate used for bill estimation is an illustrative average slab rate. "
               "Adjust in recommendations.py to match actual local tariffs.")

st.divider()
st.caption("Built for the TEYZIX CORE Internship Program — Machine Learning Domain — Task ID: ML-3")
