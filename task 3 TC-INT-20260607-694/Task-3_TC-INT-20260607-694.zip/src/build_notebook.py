import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

md("""# Smart Electricity Consumption Prediction & Energy Optimization System
### TEYZIX CORE Internship Program — Task ID: ML-3 (Machine Learning Domain)

**Author:** Khanum (Bushra) Khan — Sukkur IBA University, BS Computer Science (Batch 2026)
**Program:** DecodeLabs / TEYZIX CORE Internship, June Batch

This notebook documents the complete ML lifecycle for the project:
1. Original Dataset Creation
2. Data Preprocessing
3. Exploratory Data Analysis (EDA)
4. Feature Engineering
5. Model Training & Comparison (6 algorithms)
6. Model Evaluation
7. Prediction & Energy Optimization Recommendations
8. Report Generation

> **Note on dataset originality:** No public dataset (Kaggle/UCI/GitHub) is used. The dataset is
> generated using a physics-informed synthetic data model based on typical household appliance
> power ratings, described in Section 1 below.
""")

code("""import sys, os
sys.path.append(os.path.abspath('../src'))
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_theme(style='whitegrid')

pd.set_option('display.max_columns', None)
""")

md("## 1. Original Dataset Creation\n\nWe generate a realistic, original synthetic dataset of household electricity usage using a physics-informed additive model (see `src/generate_dataset.py` for full methodology).")

code("""from generate_dataset import generate_dataset

df_raw = generate_dataset()
print("Shape:", df_raw.shape)
df_raw.head()
""")

code("""df_raw.info()
""")

md("## 2. Data Preprocessing\n\nHandling missing values, duplicates, outliers, encoding, and scaling.")

code("""from preprocessing import preprocess

df_processed, report = preprocess()
for k, v in report.items():
    print(f"{k}: {v}")
df_processed.head()
""")

md("## 3. Exploratory Data Analysis (EDA)")

code("""summary = df_processed[[
    'Family_Members','Num_Rooms','AC_Usage_Hours','Fan_Usage_Hours',
    'Fridge_Usage_Hours','Washing_Machine_Hours','Water_Motor_Hours',
    'Lighting_Hours','Heater_Usage_Hours','TV_Electronics_Hours',
    'Daily_Appliance_Count','Outdoor_Temperature_C',
    'Daily_Electricity_Consumption_kWh'
]].describe().T
summary
""")

code("""plt.figure(figsize=(11,9))
corr = df_processed[[
    'Family_Members','Num_Rooms','AC_Usage_Hours','Fan_Usage_Hours',
    'Fridge_Usage_Hours','Washing_Machine_Hours','Water_Motor_Hours',
    'Lighting_Hours','Heater_Usage_Hours','TV_Electronics_Hours',
    'Daily_Appliance_Count','Outdoor_Temperature_C',
    'Daily_Electricity_Consumption_kWh'
]].corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='YlGnBu')
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.show()
""")

code("""fig, axes = plt.subplots(1, 3, figsize=(16,5))
sns.scatterplot(x='AC_Usage_Hours', y='Daily_Electricity_Consumption_kWh', data=df_processed, ax=axes[0], alpha=0.6)
sns.scatterplot(x='Outdoor_Temperature_C', y='Daily_Electricity_Consumption_kWh', data=df_processed, ax=axes[1], alpha=0.6)
sns.boxplot(x='Season', y='Daily_Electricity_Consumption_kWh', data=df_processed, ax=axes[2])
plt.tight_layout()
plt.show()
""")

md("""**Business Insights:**
- AC usage hours and outdoor temperature show the strongest positive correlation with daily electricity consumption.
- Larger families and homes with more rooms consume more electricity overall.
- Summer season shows the highest average consumption due to AC-driven cooling load.
""")

md("## 4. Feature Engineering")

code("""from feature_engineering import engineer_features, evaluate_feature_importance

df_feat, features = engineer_features(df_processed)
importance = evaluate_feature_importance(df_feat, features)
importance.head(10)
""")

md("## 5. Model Training & Comparison\n\nSix regression algorithms are trained and compared: Linear Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost, and Support Vector Regression.")

code("""from train_models import main as train_main

results_df, best_model_name = train_main()
results_df
""")

code("""print("Best performing model:", best_model_name)
""")

md("## 6. Model Evaluation\n\nSee `plots/actual_vs_predicted.png` and `plots/model_comparison.png` for visual evaluation of the best model versus alternatives.")

code("""from IPython.display import Image
Image(filename='../plots/actual_vs_predicted.png')
""")

md("## 7. Prediction System & Energy Optimization Recommendations\n\nA sample prediction using the trained model, demonstrating the full recommendation engine output.")

code("""import joblib
from recommendations import generate_recommendations

model = joblib.load('../models/best_model.pkl')
feature_list = joblib.load('../models/feature_list.pkl')
encoders = joblib.load('../models/label_encoders.pkl')

sample = {
    'Family_Members': 5, 'Num_Rooms': 4, 'AC_Usage_Hours': 7, 'Fan_Usage_Hours': 12,
    'Fridge_Usage_Hours': 22, 'Washing_Machine_Hours': 1, 'Water_Motor_Hours': 1.5,
    'Lighting_Hours': 8, 'Heater_Usage_Hours': 2, 'TV_Electronics_Hours': 5,
    'Daily_Appliance_Count': 10, 'Outdoor_Temperature_C': 38,
    'House_Type_Encoded': encoders['House_Type'].transform(['Independent House'])[0],
    'Day_of_Week_Encoded': encoders['Day_of_Week'].transform(['Saturday'])[0],
    'Season_Encoded': encoders['Season'].transform(['Summer'])[0],
    'Is_Working_Day': 0,
}

sample_df = pd.DataFrame([sample])
sample_df, _ = engineer_features(sample_df)
prediction = model.predict(sample_df[feature_list])[0]

result = generate_recommendations(sample, prediction)
print(f"Predicted Daily Consumption: {prediction:.2f} kWh")
print(f"Estimated Monthly Usage: {result['estimated_monthly_kwh']} kWh")
print(f"Estimated Monthly Bill: PKR {result['estimated_monthly_bill_pkr']}")
print(f"Efficiency Score: {result['efficiency_score']}/100")
print("Peak Hours:", result['peak_hours'])
print("Recommendations:")
for r in result['recommendations']:
    print(" -", r)
""")

md("""## 8. Conclusion

This notebook demonstrates the complete machine learning lifecycle for the Smart Electricity
Consumption Prediction & Energy Optimization System: from original synthetic dataset creation
through preprocessing, EDA, feature engineering, multi-model comparison, evaluation, and a
working prediction + recommendation system. See `reports/` for the full Excel/PDF reports and
`src/app.py` for the interactive Streamlit deployment.
""")

nb['cells'] = cells
with open('/home/claude/teyzix_ml3/notebooks/ML3_Smart_Electricity_Analysis.ipynb', 'w') as f:
    nbf.write(nb, f)

print("Notebook created.")
