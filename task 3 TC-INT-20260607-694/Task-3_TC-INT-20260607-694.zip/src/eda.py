"""
eda.py
------
Exploratory Data Analysis: statistical summary, distributions, correlation heatmap,
boxplots, scatter plots, and feature relationships.
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
DATA_PATH = "/home/claude/teyzix_ml3/data/processed_dataset.csv"
PLOTS_DIR = "/home/claude/teyzix_ml3/plots"
TARGET = "Daily_Electricity_Consumption_kWh"

NUMERIC_COLS = [
    "Family_Members", "Num_Rooms", "AC_Usage_Hours", "Fan_Usage_Hours",
    "Fridge_Usage_Hours", "Washing_Machine_Hours", "Water_Motor_Hours",
    "Lighting_Hours", "Heater_Usage_Hours", "TV_Electronics_Hours",
    "Daily_Appliance_Count", "Outdoor_Temperature_C", TARGET,
]


def run_eda():
    df = pd.read_csv(DATA_PATH)

    # 1. Statistical summary
    summary = df[NUMERIC_COLS].describe().T
    summary.to_csv(f"{PLOTS_DIR}/statistical_summary.csv")

    # 2. Correlation heatmap
    plt.figure(figsize=(11, 9))
    corr = df[NUMERIC_COLS].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="YlGnBu", square=True, cbar_kws={"shrink": 0.8})
    plt.title("Correlation Heatmap - Numeric Features vs Electricity Consumption")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/correlation_heatmap.png", dpi=140)
    plt.close()

    # 3. Distribution histograms (target + key features)
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    hist_cols = [TARGET, "AC_Usage_Hours", "Outdoor_Temperature_C",
                 "Family_Members", "Lighting_Hours", "Fan_Usage_Hours"]
    for ax, col in zip(axes.flat, hist_cols):
        sns.histplot(df[col], kde=True, ax=ax, color="#2E7D32")
        ax.set_title(f"Distribution of {col}")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/feature_distributions.png", dpi=140)
    plt.close()

    # 4. Box plots (target by categorical features)
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    sns.boxplot(x="House_Type", y=TARGET, data=df, ax=axes[0], palette="Greens")
    axes[0].set_title("Consumption by House Type")
    sns.boxplot(x="Season", y=TARGET, data=df, ax=axes[1], palette="Greens")
    axes[1].set_title("Consumption by Season")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/boxplots_categorical.png", dpi=140)
    plt.close()

    # 5. Scatter plots (feature relationships with target)
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    sns.scatterplot(x="AC_Usage_Hours", y=TARGET, data=df, ax=axes[0], alpha=0.6, color="#1565C0")
    axes[0].set_title("AC Hours vs Consumption")
    sns.scatterplot(x="Outdoor_Temperature_C", y=TARGET, data=df, ax=axes[1], alpha=0.6, color="#EF6C00")
    axes[1].set_title("Outdoor Temp vs Consumption")
    sns.scatterplot(x="Family_Members", y=TARGET, data=df, ax=axes[2], alpha=0.6, color="#6A1B9A")
    axes[2].set_title("Family Members vs Consumption")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/scatter_relationships.png", dpi=140)
    plt.close()

    # Business insights (from correlation with target)
    target_corr = corr[TARGET].drop(TARGET).sort_values(ascending=False)
    insights = target_corr.to_dict()

    return summary, insights


if __name__ == "__main__":
    summary, insights = run_eda()
    print("EDA complete. Plots saved to /plots directory.\n")
    print("Top correlated features with electricity consumption:")
    for k, v in sorted(insights.items(), key=lambda x: -abs(x[1]))[:8]:
        print(f"  {k}: {v:.3f}")
