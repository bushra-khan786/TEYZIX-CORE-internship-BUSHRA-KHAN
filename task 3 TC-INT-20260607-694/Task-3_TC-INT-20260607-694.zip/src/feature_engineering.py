"""
feature_engineering.py
-----------------------
Feature selection, transformation, and importance evaluation.
Produces the final modeling feature set used by train_models.py
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor

DATA_PATH = "/home/claude/teyzix_ml3/data/processed_dataset.csv"
TARGET = "Daily_Electricity_Consumption_kWh"

BASE_FEATURES = [
    "Family_Members", "Num_Rooms", "AC_Usage_Hours", "Fan_Usage_Hours",
    "Fridge_Usage_Hours", "Washing_Machine_Hours", "Water_Motor_Hours",
    "Lighting_Hours", "Heater_Usage_Hours", "TV_Electronics_Hours",
    "Daily_Appliance_Count", "Outdoor_Temperature_C",
    "House_Type_Encoded", "Day_of_Week_Encoded", "Season_Encoded", "Is_Working_Day",
]


def engineer_features(df):
    # Transformation: interaction features that reflect real energy-usage patterns
    df["High_Power_Load_Index"] = df["AC_Usage_Hours"] + df["Heater_Usage_Hours"] * 1.2
    df["Appliance_Density"] = df["Daily_Appliance_Count"] / df["Num_Rooms"].replace(0, 1)
    df["Temp_AC_Interaction"] = df["Outdoor_Temperature_C"] * df["AC_Usage_Hours"] / 10

    engineered_features = BASE_FEATURES + [
        "High_Power_Load_Index", "Appliance_Density", "Temp_AC_Interaction"
    ]
    return df, engineered_features


def evaluate_feature_importance(df, features):
    X, y = df[features], df[TARGET]
    rf = RandomForestRegressor(n_estimators=200, random_state=42)
    rf.fit(X, y)
    importance = pd.Series(rf.feature_importances_, index=features).sort_values(ascending=False)
    return importance


if __name__ == "__main__":
    df = pd.read_csv(DATA_PATH)
    df, features = engineer_features(df)
    importance = evaluate_feature_importance(df, features)

    df.to_csv("/home/claude/teyzix_ml3/data/featured_dataset.csv", index=False)
    importance.to_csv("/home/claude/teyzix_ml3/reports/feature_importance.csv")

    print("Feature engineering complete.")
    print(f"Total features used for modeling: {len(features)}")
    print("\nTop 10 most important features:")
    print(importance.head(10))
