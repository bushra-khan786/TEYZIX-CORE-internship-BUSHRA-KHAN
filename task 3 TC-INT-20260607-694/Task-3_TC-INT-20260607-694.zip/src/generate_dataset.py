"""
generate_dataset.py
--------------------
TEYZIX CORE Internship - Task ML-3
Smart Electricity Consumption Prediction & Energy Optimization System

This script generates an ORIGINAL, synthetic household electricity-usage dataset.
No public dataset (Kaggle/UCI/GitHub) is used anywhere in this project.

Methodology
-----------
The dataset is generated using a realistic synthetic-data-generation approach that
models household electricity consumption as a function of:
    - Household characteristics (house type, family size, number of rooms)
    - Appliance usage patterns (AC, fan, fridge, washing machine, water motor,
      lighting, heater, TV/electronics)
    - Environmental factors (outdoor temperature, season)
    - Temporal factors (day of week, weekend/holiday status)

A physics-informed additive model (approximate real-world appliance wattage /
usage-hour relationships, based on publicly documented typical appliance power
ratings in Pakistan/South-Asian households) is combined with household-level
random effects and Gaussian noise to produce a realistic, non-trivial regression
target. This mirrors how real smart-meter datasets behave (not perfectly linear,
some noise, some interaction effects) while remaining fully original and
reproducible (fixed random seed).
"""

import numpy as np
import pandas as pd

RANDOM_SEED = 42
N_RECORDS = 650  # > 500 required

rng = np.random.default_rng(RANDOM_SEED)

HOUSE_TYPES = ["Apartment", "Independent House", "Villa"]
HOUSE_TYPE_WEIGHTS = [0.45, 0.40, 0.15]
HOUSE_TYPE_MULTIPLIER = {"Apartment": 0.85, "Independent House": 1.0, "Villa": 1.35}

SEASONS = ["Summer", "Winter", "Spring", "Autumn"]
SEASON_WEIGHTS = [0.35, 0.25, 0.20, 0.20]

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def sample_season_temperature(season, n):
    """Outdoor temperature (Celsius) sampled per season, South-Asian climate."""
    ranges = {
        "Summer": (32, 46),
        "Winter": (8, 20),
        "Spring": (20, 32),
        "Autumn": (18, 30),
    }
    low, high = ranges[season]
    return rng.uniform(low, high, n)


def generate_dataset(n=N_RECORDS):
    house_type = rng.choice(HOUSE_TYPES, size=n, p=HOUSE_TYPE_WEIGHTS)
    family_members = rng.integers(1, 9, n)  # 1-8
    num_rooms = np.clip((family_members / 1.6 + rng.normal(0, 0.8, n)).round(), 1, 8).astype(int)

    season = rng.choice(SEASONS, size=n, p=SEASON_WEIGHTS)
    outdoor_temp = np.array([sample_season_temperature(s, 1)[0] for s in season]).round(1)

    day_of_week = rng.choice(DAYS, size=n)
    is_weekend = np.isin(day_of_week, ["Saturday", "Sunday"]).astype(int)
    is_holiday = rng.choice([0, 1], size=n, p=[0.92, 0.08])
    working_day_flag = np.where((is_weekend == 1) | (is_holiday == 1), 0, 1)

    # --- Appliance usage hours (correlated with temperature, family size, house type) ---
    # AC usage rises sharply with temperature and house size
    ac_base = np.clip((outdoor_temp - 24) * 0.55, 0, None)
    ac_hours = np.clip(
        ac_base + rng.normal(0, 1.5, n) + (family_members * 0.25), 0, 18
    ).round(1)
    ac_hours = np.where(season == "Winter", np.clip(ac_hours * 0.05, 0, 1), ac_hours)

    heater_hours = np.where(
        season == "Winter",
        np.clip(rng.normal(4, 1.8, n) + (24 - outdoor_temp) * 0.15, 0, 12),
        np.clip(rng.normal(0.2, 0.4, n), 0, 2),
    ).round(1)

    fan_hours = np.clip(
        rng.normal(10, 3, n) + np.where(season == "Summer", 2, 0), 0, 24
    ).round(1)

    fridge_usage_hours = np.clip(rng.normal(22, 1.5, n), 16, 24).round(1)  # near-constant
    washing_machine_hours = np.clip(rng.normal(0.6, 0.4, n) + is_weekend * 0.4, 0, 3).round(2)
    water_motor_hours = np.clip(rng.normal(1.0, 0.5, n) + num_rooms * 0.05, 0, 4).round(2)
    lighting_hours = np.clip(rng.normal(6, 1.5, n) + num_rooms * 0.3, 2, 14).round(1)
    tv_electronics_hours = np.clip(rng.normal(4.5, 2, n) + is_weekend * 1.2, 0, 14).round(1)

    daily_appliance_count = np.clip(
        (num_rooms + family_members / 2 + rng.normal(2, 1, n)).round(), 3, 20
    ).astype(int)

    # --- Approximate typical power ratings (kW) used for the physics-informed model ---
    P_AC, P_FAN, P_FRIDGE, P_WM, P_MOTOR = 1.5, 0.075, 0.15, 0.5, 0.75
    P_LIGHT, P_HEATER, P_TV = 0.08, 1.2, 0.12

    base_load = 0.8  # standby/misc base load (kWh/day)

    consumption = (
        base_load
        + ac_hours * P_AC
        + fan_hours * P_FAN
        + fridge_usage_hours * P_FRIDGE
        + washing_machine_hours * P_WM
        + water_motor_hours * P_MOTOR
        + lighting_hours * P_LIGHT
        + heater_hours * P_HEATER
        + tv_electronics_hours * P_TV
        + family_members * 0.35
        + num_rooms * 0.25
    )

    # House-type multiplier (bigger houses -> more overall load / distribution losses)
    consumption = consumption * np.array([HOUSE_TYPE_MULTIPLIER[h] for h in house_type])

    # Random household-level effect (some homes are just less/more efficient)
    household_effect = rng.normal(1.0, 0.08, n)
    consumption = consumption * household_effect

    # Add realistic measurement/behavioral noise
    consumption = consumption + rng.normal(0, 1.1, n)
    consumption = np.clip(consumption, 2, None).round(2)  # kWh/day, floor at 2

    df = pd.DataFrame(
        {
            "House_Type": house_type,
            "Family_Members": family_members,
            "Num_Rooms": num_rooms,
            "AC_Usage_Hours": ac_hours,
            "Fan_Usage_Hours": fan_hours,
            "Fridge_Usage_Hours": fridge_usage_hours,
            "Washing_Machine_Hours": washing_machine_hours,
            "Water_Motor_Hours": water_motor_hours,
            "Lighting_Hours": lighting_hours,
            "Heater_Usage_Hours": heater_hours,
            "TV_Electronics_Hours": tv_electronics_hours,
            "Daily_Appliance_Count": daily_appliance_count,
            "Outdoor_Temperature_C": outdoor_temp,
            "Day_of_Week": day_of_week,
            "Season": season,
            "Is_Working_Day": working_day_flag,
            "Daily_Electricity_Consumption_kWh": consumption,
        }
    )

    # --- Inject realistic data-quality issues (to be handled during preprocessing) ---
    # 1. Missing values (~2%) in a few columns
    for col in ["AC_Usage_Hours", "Lighting_Hours", "Outdoor_Temperature_C"]:
        miss_idx = rng.choice(df.index, size=int(0.02 * n), replace=False)
        df.loc[miss_idx, col] = np.nan

    # 2. Duplicate rows (~1%)
    dup_idx = rng.choice(df.index, size=int(0.01 * n), replace=False)
    df = pd.concat([df, df.loc[dup_idx]], ignore_index=True)

    # 3. A few extreme outliers (~0.5%)
    out_idx = rng.choice(df.index, size=max(2, int(0.005 * n)), replace=False)
    df.loc[out_idx, "Daily_Electricity_Consumption_kWh"] *= 3.2

    df = df.sample(frac=1, random_state=RANDOM_SEED).reset_index(drop=True)
    return df


if __name__ == "__main__":
    dataset = generate_dataset()
    dataset.to_csv("/home/claude/teyzix_ml3/data/household_electricity_dataset.csv", index=False)
    print(f"Dataset generated: {dataset.shape[0]} rows, {dataset.shape[1]} columns")
    print(dataset.head())
    print("\nMissing values:\n", dataset.isna().sum())
    print("\nDuplicate rows:", dataset.duplicated().sum())
