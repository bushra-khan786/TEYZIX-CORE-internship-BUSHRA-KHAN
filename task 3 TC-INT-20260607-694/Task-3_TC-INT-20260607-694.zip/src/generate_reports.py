"""
generate_reports.py
---------------------
Generates:
  1. reports/Full_Report.xlsx  (Dataset Summary, Model Performance, Feature Importance,
     Energy Consumption Report, Monthly Forecast, Recommendation Summary)
  2. reports/Energy_Consumption_Report.pdf (executive summary, plots, key numbers)
"""

import pandas as pd
import json
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, PatternFill, Alignment
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

DATA_DIR = "/home/claude/teyzix_ml3/data"
REPORTS_DIR = "/home/claude/teyzix_ml3/reports"
PLOTS_DIR = "/home/claude/teyzix_ml3/plots"


def style_header(ws, row=1):
    for cell in ws[row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="2E7D32", end_color="2E7D32", fill_type="solid")
        cell.alignment = Alignment(horizontal="center")


def build_excel_report():
    df = pd.read_csv(f"{DATA_DIR}/household_electricity_dataset.csv")
    model_perf = pd.read_csv(f"{REPORTS_DIR}/model_performance_report.csv")
    feat_imp = pd.read_csv(f"{REPORTS_DIR}/feature_importance.csv")
    feat_imp.columns = ["Feature", "Importance"]

    with open(f"{REPORTS_DIR}/best_model_info.json") as f:
        best_info = json.load(f)

    wb = Workbook()

    # Sheet 1: Dataset Summary
    ws1 = wb.active
    ws1.title = "Dataset Summary"
    ws1.append(["Metric", "Value"])
    summary_rows = [
        ("Total Records", len(df)),
        ("Total Features", df.shape[1] - 1),
        ("Target Variable", "Daily_Electricity_Consumption_kWh"),
        ("Data Collection Method", "Realistic synthetic data generation (physics-informed model)"),
        ("Missing Values (raw)", int(df.isna().sum().sum())),
        ("Duplicate Rows (raw)", int(df.duplicated().sum())),
        ("Avg Daily Consumption (kWh)", round(df["Daily_Electricity_Consumption_kWh"].mean(), 2)),
        ("Max Daily Consumption (kWh)", round(df["Daily_Electricity_Consumption_kWh"].max(), 2)),
        ("Min Daily Consumption (kWh)", round(df["Daily_Electricity_Consumption_kWh"].min(), 2)),
    ]
    for r in summary_rows:
        ws1.append(list(r))
    style_header(ws1)
    ws1.column_dimensions["A"].width = 32
    ws1.column_dimensions["B"].width = 45

    # Sheet 2: Model Performance
    ws2 = wb.create_sheet("Model Performance")
    for row in dataframe_to_rows(model_perf, index=False, header=True):
        ws2.append(row)
    style_header(ws2)
    for col in "ABCDE":
        ws2.column_dimensions[col].width = 22

    # Sheet 3: Feature Importance
    ws3 = wb.create_sheet("Feature Importance")
    for row in dataframe_to_rows(feat_imp, index=False, header=True):
        ws3.append(row)
    style_header(ws3)
    ws3.column_dimensions["A"].width = 28
    ws3.column_dimensions["B"].width = 18

    # Sheet 4: Energy Consumption Report (aggregate insights)
    ws4 = wb.create_sheet("Energy Consumption Report")
    by_house = df.groupby("House_Type")["Daily_Electricity_Consumption_kWh"].mean().round(2)
    by_season = df.groupby("Season")["Daily_Electricity_Consumption_kWh"].mean().round(2)
    ws4.append(["Average Daily Consumption by House Type"])
    ws4.append(["House Type", "Avg Daily kWh"])
    for k, v in by_house.items():
        ws4.append([k, v])
    ws4.append([])
    ws4.append(["Average Daily Consumption by Season"])
    ws4.append(["Season", "Avg Daily kWh"])
    for k, v in by_season.items():
        ws4.append([k, v])
    style_header(ws4, row=2)

    # Sheet 5: Monthly Usage Forecast (illustrative, based on average household)
    ws5 = wb.create_sheet("Monthly Forecast")
    avg_daily = df["Daily_Electricity_Consumption_kWh"].mean()
    ws5.append(["Month (Illustrative)", "Forecasted kWh", "Estimated Bill (PKR @45/kWh)"])
    season_cycle = ["Winter", "Winter", "Spring", "Spring", "Spring", "Summer",
                    "Summer", "Summer", "Autumn", "Autumn", "Autumn", "Winter"]
    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    for m, s in zip(month_names, season_cycle):
        seasonal_avg = by_season.get(s, avg_daily)
        monthly_kwh = round(seasonal_avg * 30, 2)
        ws5.append([m, monthly_kwh, round(monthly_kwh * 45, 2)])
    style_header(ws5)
    for col in "ABC":
        ws5.column_dimensions[col].width = 26

    # Sheet 6: Recommendation Summary
    ws6 = wb.create_sheet("Recommendation Summary")
    ws6.append(["Condition", "Recommendation", "Typical Est. Savings"])
    recs = [
        ("AC usage > 6 hrs/day", "Raise thermostat by 1-2C or reduce AC usage by 1 hr/day", "~8%"),
        ("Heater usage > 4 hrs/day", "Limit heater use to peak-cold hours (7-10 PM)", "~6%"),
        ("Lighting > 8 hrs/day", "Switch to LEDs + motion-sensor lighting", "~4%"),
        ("Washing machine > 1 hr/day", "Run full loads during off-peak hours", "~3%"),
        ("Fan usage > 14 hrs/day", "Switch off fans in unoccupied rooms", "~3%"),
    ]
    for row in recs:
        ws6.append(list(row))
    style_header(ws6)
    for col in "ABC":
        ws6.column_dimensions[col].width = 32

    wb.save(f"{REPORTS_DIR}/Full_Report.xlsx")
    return best_info


def build_pdf_report(best_info):
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleGreen", parent=styles["Title"], textColor=colors.HexColor("#2E7D32"))
    h2 = ParagraphStyle("H2Green", parent=styles["Heading2"], textColor=colors.HexColor("#1565C0"))

    doc = SimpleDocTemplate(f"{REPORTS_DIR}/Energy_Consumption_Report.pdf", pagesize=A4,
                             topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    story = []
    story.append(Paragraph("Smart Electricity Consumption Prediction &amp; Energy Optimization System", title_style))
    story.append(Paragraph("TEYZIX CORE Internship Program — Task ID: ML-3", styles["Normal"]))
    story.append(Spacer(1, 16))

    story.append(Paragraph("Executive Summary", h2))
    story.append(Paragraph(
        "This report summarizes the machine learning pipeline built to predict household daily "
        "electricity consumption and generate personalized energy-saving recommendations. "
        "An original synthetic dataset of 650+ records was created, cleaned, analyzed, and used "
        "to train and compare six regression algorithms.", styles["BodyText"]))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Best Performing Model", h2))
    m = best_info["metrics"]
    table_data = [["Model", "MAE", "MSE", "RMSE", "R2 Score"],
                  [m["Model"], m["MAE"], m["MSE"], m["RMSE"], m["R2_Score"]]]
    t = Table(table_data, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E7D32")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    story.append(Paragraph("Correlation Heatmap", h2))
    story.append(Image(f"{PLOTS_DIR}/correlation_heatmap.png", width=15 * cm, height=12 * cm))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Model Comparison", h2))
    story.append(Image(f"{PLOTS_DIR}/model_comparison.png", width=15 * cm, height=8.5 * cm))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Actual vs Predicted Consumption", h2))
    story.append(Image(f"{PLOTS_DIR}/actual_vs_predicted.png", width=13 * cm, height=11 * cm))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Key Insight", h2))
    story.append(Paragraph(
        "AC usage hours and outdoor temperature are the strongest drivers of daily electricity "
        "consumption, followed by fan usage and family size. Households can achieve meaningful "
        "savings primarily by optimizing AC and heater usage during peak hours.", styles["BodyText"]))

    doc.build(story)


if __name__ == "__main__":
    best_info = build_excel_report()
    build_pdf_report(best_info)
    print("Reports generated: Full_Report.xlsx, Energy_Consumption_Report.pdf")
