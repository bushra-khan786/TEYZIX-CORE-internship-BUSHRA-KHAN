"""
predict.py
-----------
Simple CLI prediction interface for the Smart Electricity Consumption
Prediction & Energy Optimization System.

Run: python3 predict.py
"""

import joblib
import pandas as pd
from feature_engineering import engineer_features
from recommendations import generate_recommendations

MODELS_DIR = "/home/claude/teyzix_ml3/models"


def load_artifacts():
    model = joblib.load(f"{MODELS_DIR}/best_model.pkl")
    features = joblib.load(f"{MODELS_DIR}/feature_list.pkl")
    encoders = joblib.load(f"{MODELS_DIR}/label_encoders.pkl")
    return model, features, encoders


def get_input(prompt, cast=float, default=None):
    raw = input(f"{prompt} [{default}]: ").strip()
    if raw == "" and default is not None:
        return cast(default)
    return cast(raw)


def main():
    model, features, encoders = load_artifacts()

    print("=" * 60)
    print(" Smart Electricity Consumption Prediction System (CLI)")
    print("=" * 60)

    house_type = get_input("House Type (Apartment/Independent House/Villa)", str, "Independent House")
    family_members = get_input("Number of Family Members", int, 4)
    num_rooms = get_input("Number of Rooms", int, 3)
    ac_hours = get_input("AC Usage Hours/day", float, 4)
    fan_hours = get_input("Fan Usage Hours/day", float, 10)
    fridge_hours = get_input("Fridge Usage Hours/day", float, 22)
    wm_hours = get_input("Washing Machine Hours/day", float, 0.5)
    motor_hours = get_input("Water Motor Hours/day", float, 1)
    lighting_hours = get_input("Lighting Hours/day", float, 6)
    heater_hours = get_input("Heater Usage Hours/day", float, 0)
    tv_hours = get_input("TV/Electronics Hours/day", float, 4)
    appliance_count = get_input("Total Daily Appliance Count", int, 8)
    temp = get_input("Outdoor Temperature (C)", float, 30)
    day = get_input("Day of Week (Monday..Sunday)", str, "Monday")
    season = get_input("Season (Summer/Winter/Spring/Autumn)", str, "Summer")
    is_working_day = get_input("Is Working Day (1/0)", int, 1)

    row = {
        "Family_Members": family_members, "Num_Rooms": num_rooms,
        "AC_Usage_Hours": ac_hours, "Fan_Usage_Hours": fan_hours,
        "Fridge_Usage_Hours": fridge_hours, "Washing_Machine_Hours": wm_hours,
        "Water_Motor_Hours": motor_hours, "Lighting_Hours": lighting_hours,
        "Heater_Usage_Hours": heater_hours, "TV_Electronics_Hours": tv_hours,
        "Daily_Appliance_Count": appliance_count, "Outdoor_Temperature_C": temp,
        "House_Type_Encoded": encoders["House_Type"].transform([house_type])[0],
        "Day_of_Week_Encoded": encoders["Day_of_Week"].transform([day])[0],
        "Season_Encoded": encoders["Season"].transform([season])[0],
        "Is_Working_Day": is_working_day,
    }

    df_row = pd.DataFrame([row])
    df_row, _ = engineer_features(df_row)
    prediction = model.predict(df_row[features])[0]

    rec_input = row.copy()
    rec_input["Family_Members"] = family_members
    rec_input["Num_Rooms"] = num_rooms
    result = generate_recommendations(rec_input, prediction)

    print("\n" + "=" * 60)
    print(f" Predicted Daily Electricity Consumption : {prediction:.2f} kWh")
    print(f" Estimated Monthly Electricity Usage      : {result['estimated_monthly_kwh']} kWh")
    print(f" Estimated Monthly Electricity Bill        : PKR {result['estimated_monthly_bill_pkr']}")
    print(f" Energy Efficiency Score                   : {result['efficiency_score']} / 100")
    print(f" Peak Usage Hours                          : {', '.join(result['peak_hours'])}")
    print("=" * 60)
    print("\n Personalized Energy-Saving Recommendations:")
    for r in result["recommendations"]:
        print(f"  - {r}")
    print(f"\n Estimated Potential Monthly Savings: {result['estimated_savings_percent']}% "
          f"(~PKR {result['estimated_monthly_savings_pkr']})")


if __name__ == "__main__":
    main()
