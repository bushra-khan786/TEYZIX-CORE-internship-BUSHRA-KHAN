"""
preprocessing.py
-----------------
Handles: missing value imputation, duplicate removal, outlier detection/treatment,
categorical encoding, and feature scaling.
"""

import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler, LabelEncoder

RAW_PATH = "/home/claude/teyzix_ml3/data/household_electricity_dataset.csv"
OUT_PATH = "/home/claude/teyzix_ml3/data/processed_dataset.csv"
ENCODERS_PATH = "/home/claude/teyzix_ml3/models/label_encoders.pkl"
SCALER_PATH = "/home/claude/teyzix_ml3/models/scaler.pkl"

TARGET = "Daily_Electricity_Consumption_kWh"
CATEGORICAL_COLS = ["House_Type", "Day_of_Week", "Season"]
NUMERIC_COLS = [
    "Family_Members", "Num_Rooms", "AC_Usage_Hours", "Fan_Usage_Hours",
    "Fridge_Usage_Hours", "Washing_Machine_Hours", "Water_Motor_Hours",
    "Lighting_Hours", "Heater_Usage_Hours", "TV_Electronics_Hours",
    "Daily_Appliance_Count", "Outdoor_Temperature_C",
]


def remove_outliers_iqr(df, col, factor=3.0):
    """Cap outliers using the IQR method instead of dropping rows (preserves data)."""
    q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - factor * iqr, q3 + factor * iqr
    n_outliers = ((df[col] < lower) | (df[col] > upper)).sum()
    df[col] = df[col].clip(lower, upper)
    return df, n_outliers


def preprocess():
    df = pd.read_csv(RAW_PATH)
    report = {}

    report["initial_rows"] = len(df)

    # 1. Duplicate removal
    dup_count = df.duplicated().sum()
    df = df.drop_duplicates().reset_index(drop=True)
    report["duplicates_removed"] = int(dup_count)

    # 2. Missing value handling (median for numeric)
    missing_before = df.isna().sum().sum()
    for col in NUMERIC_COLS:
        if df[col].isna().sum() > 0:
            df[col] = df[col].fillna(df[col].median())
    report["missing_values_imputed"] = int(missing_before)

    # 3. Outlier detection & treatment (IQR capping) on target + key numeric features
    outlier_log = {}
    for col in NUMERIC_COLS + [TARGET]:
        df, n_out = remove_outliers_iqr(df, col)
        outlier_log[col] = int(n_out)
    report["outliers_capped_per_column"] = outlier_log

    # 4. Feature encoding (Label Encoding for tree models + one-hot alternative kept simple)
    encoders = {}
    for col in CATEGORICAL_COLS:
        le = LabelEncoder()
        df[col + "_Encoded"] = le.fit_transform(df[col])
        encoders[col] = le

    # 5. Feature scaling (StandardScaler on numeric features, target left in original units)
    scaler = StandardScaler()
    scaled = scaler.fit_transform(df[NUMERIC_COLS])
    scaled_df = pd.DataFrame(scaled, columns=[c + "_Scaled" for c in NUMERIC_COLS])
    df = pd.concat([df.reset_index(drop=True), scaled_df], axis=1)

    report["final_rows"] = len(df)
    report["final_columns"] = df.shape[1]

    df.to_csv(OUT_PATH, index=False)
    joblib.dump(encoders, ENCODERS_PATH)
    joblib.dump(scaler, SCALER_PATH)

    return df, report


if __name__ == "__main__":
    df, report = preprocess()
    print("Preprocessing complete.")
    for k, v in report.items():
        print(f"  {k}: {v}")
    print("\nProcessed shape:", df.shape)
