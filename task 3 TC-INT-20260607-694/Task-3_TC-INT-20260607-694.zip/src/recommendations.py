"""
recommendations.py
--------------------
Generates personalized energy-optimization recommendations based on
predicted consumption and appliance usage patterns.
"""

ELECTRICITY_RATE_PKR_PER_KWH = 45  # approximate average slab rate used for illustration


def estimate_bill(monthly_kwh, rate=ELECTRICITY_RATE_PKR_PER_KWH):
    return round(monthly_kwh * rate, 2)


def energy_efficiency_score(daily_kwh, family_members, num_rooms):
    """
    Simple efficiency score (0-100): lower consumption per person/room = higher score.
    Benchmarked against a reasonable per-capita/per-room usage assumption.
    """
    per_capita = daily_kwh / max(family_members, 1)
    per_room = daily_kwh / max(num_rooms, 1)
    benchmark_per_capita = 3.0   # kWh/person/day (reasonable efficient household)
    benchmark_per_room = 2.2     # kWh/room/day

    score = 100 - (
        (max(per_capita - benchmark_per_capita, 0) / benchmark_per_capita) * 40
        + (max(per_room - benchmark_per_room, 0) / benchmark_per_room) * 40
    )
    return round(max(min(score, 100), 0), 1)


def peak_usage_hours(ac_hours, heater_hours, washing_machine_hours):
    """Heuristic peak-hour estimation based on typical usage windows."""
    peaks = []
    if ac_hours > 4:
        peaks.append("2:00 PM - 6:00 PM (AC-driven afternoon peak)")
    if heater_hours > 2:
        peaks.append("7:00 PM - 10:00 PM (Heater-driven evening peak)")
    if washing_machine_hours > 0.5:
        peaks.append("9:00 AM - 11:00 AM (Laundry peak)")
    if not peaks:
        peaks.append("6:00 PM - 9:00 PM (General evening peak)")
    return peaks


def generate_recommendations(inputs, predicted_daily_kwh):
    """
    inputs: dict with keys matching the prediction form
    Returns a dict of recommendation strings + estimated savings.
    """
    recs = []
    est_savings_pct = 0

    if inputs["AC_Usage_Hours"] > 6:
        recs.append("AC usage is high — raising the thermostat by 1-2°C or reducing "
                     "usage by 1 hour/day can meaningfully cut consumption.")
        est_savings_pct += 8

    if inputs["Heater_Usage_Hours"] > 4:
        recs.append("Heater usage is significant — consider using it only during peak-cold "
                     "hours (7-10 PM) instead of continuously.")
        est_savings_pct += 6

    if inputs["Lighting_Hours"] > 8:
        recs.append("Lighting hours are above average — switching to LED bulbs and using "
                     "motion-sensor lighting in low-traffic rooms can reduce waste.")
        est_savings_pct += 4

    if inputs["Washing_Machine_Hours"] > 1:
        recs.append("Run the washing machine with full loads and during off-peak hours "
                     "(before 9 AM or after 10 PM) to reduce peak-hour strain and cost.")
        est_savings_pct += 3

    if inputs["Fan_Usage_Hours"] > 14:
        recs.append("Fans are running for very long hours — ensure they're switched off "
                     "in unoccupied rooms.")
        est_savings_pct += 3

    if not recs:
        recs.append("Your household's appliance usage is already fairly efficient. "
                     "Maintain current habits and monitor seasonal spikes.")

    monthly_kwh = predicted_daily_kwh * 30
    monthly_bill = estimate_bill(monthly_kwh)
    est_savings_pct = min(est_savings_pct, 25)
    est_monthly_savings_pkr = round(monthly_bill * (est_savings_pct / 100), 2)

    return {
        "recommendations": recs,
        "peak_hours": peak_usage_hours(
            inputs["AC_Usage_Hours"], inputs["Heater_Usage_Hours"], inputs["Washing_Machine_Hours"]
        ),
        "estimated_monthly_kwh": round(monthly_kwh, 2),
        "estimated_monthly_bill_pkr": monthly_bill,
        "estimated_savings_percent": est_savings_pct,
        "estimated_monthly_savings_pkr": est_monthly_savings_pkr,
        "efficiency_score": energy_efficiency_score(
            predicted_daily_kwh, inputs["Family_Members"], inputs["Num_Rooms"]
        ),
    }
