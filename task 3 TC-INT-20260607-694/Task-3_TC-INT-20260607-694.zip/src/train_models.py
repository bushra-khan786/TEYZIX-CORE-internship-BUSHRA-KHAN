"""
train_models.py
-----------------
Trains and compares 5 regression algorithms:
  Linear Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost
Selects the best-performing model based on R2 / RMSE and saves it for deployment.
"""

import pandas as pd
import numpy as np
import joblib
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

from feature_engineering import engineer_features, BASE_FEATURES

DATA_PATH = "/home/claude/teyzix_ml3/data/processed_dataset.csv"
TARGET = "Daily_Electricity_Consumption_kWh"
MODELS_DIR = "/home/claude/teyzix_ml3/models"
REPORTS_DIR = "/home/claude/teyzix_ml3/reports"
PLOTS_DIR = "/home/claude/teyzix_ml3/plots"


def main():
    df = pd.read_csv(DATA_PATH)
    df, features = engineer_features(df)

    X = df[features]
    y = df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=8, random_state=42),
        "Random Forest": RandomForestRegressor(n_estimators=300, max_depth=12, random_state=42),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=250, learning_rate=0.05, max_depth=4, random_state=42),
        "XGBoost": XGBRegressor(n_estimators=300, learning_rate=0.05, max_depth=5, random_state=42, verbosity=0),
        "Support Vector Regression": SVR(kernel="rbf", C=10, epsilon=0.3),
    }

    results = []
    predictions = {}
    trained_models = {}

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        mae = mean_absolute_error(y_test, preds)
        mse = mean_squared_error(y_test, preds)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, preds)
        results.append({"Model": name, "MAE": round(mae, 3), "MSE": round(mse, 3),
                         "RMSE": round(rmse, 3), "R2_Score": round(r2, 4)})
        predictions[name] = preds
        trained_models[name] = model

    results_df = pd.DataFrame(results).sort_values("R2_Score", ascending=False).reset_index(drop=True)
    results_df.to_csv(f"{REPORTS_DIR}/model_performance_report.csv", index=False)

    best_model_name = results_df.iloc[0]["Model"]
    best_model = trained_models[best_model_name]

    # Save best model + feature list + test split for reproducibility
    joblib.dump(best_model, f"{MODELS_DIR}/best_model.pkl")
    joblib.dump(features, f"{MODELS_DIR}/feature_list.pkl")
    joblib.dump({"X_test": X_test, "y_test": y_test}, f"{MODELS_DIR}/test_split.pkl")

    with open(f"{REPORTS_DIR}/best_model_info.json", "w") as f:
        json.dump({"best_model": best_model_name,
                    "metrics": results_df.iloc[0].to_dict()}, f, indent=2)

    # Actual vs Predicted plot for the best model
    plt.figure(figsize=(7, 6))
    plt.scatter(y_test, predictions[best_model_name], alpha=0.6, color="#2E7D32")
    lims = [min(y_test.min(), predictions[best_model_name].min()),
            max(y_test.max(), predictions[best_model_name].max())]
    plt.plot(lims, lims, "r--", label="Perfect Prediction")
    plt.xlabel("Actual Daily Consumption (kWh)")
    plt.ylabel("Predicted Daily Consumption (kWh)")
    plt.title(f"Actual vs Predicted - {best_model_name}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/actual_vs_predicted.png", dpi=140)
    plt.close()

    # Model comparison bar chart
    plt.figure(figsize=(9, 5))
    plt.bar(results_df["Model"], results_df["R2_Score"], color="#1565C0")
    plt.ylabel("R2 Score")
    plt.title("Model Comparison - R2 Score")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(f"{PLOTS_DIR}/model_comparison.png", dpi=140)
    plt.close()

    return results_df, best_model_name


if __name__ == "__main__":
    results_df, best_model_name = main()
    print("Model training & comparison complete.\n")
    print(results_df.to_string(index=False))
    print(f"\nBest model selected: {best_model_name}")
